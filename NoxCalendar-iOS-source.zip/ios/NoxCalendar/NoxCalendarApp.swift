import SwiftUI

@main
struct NoxCalendarApp: App {
    @StateObject private var model = CalendarModel()
    var body: some Scene {
        WindowGroup { ContentView().environmentObject(model).preferredColorScheme(.dark) }
    }
}
