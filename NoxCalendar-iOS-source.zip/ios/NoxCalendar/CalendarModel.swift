import Foundation
import Combine
import Network
import CryptoKit
import CommonCrypto

struct ShiftConfig: Codable {
    var id = 1
    var anchorDate = "2026-01-01"
    var workDays = 2
    var restDays = 2
    var startTime = "10:00"
    var endTime = "20:00"
    var accent: Int64 = 4_289_368_575 // #FFAA91FF
    var updatedAt: Int64 = 0
    var sourceDevice = ""
}

struct ShiftEntry: Codable, Identifiable {
    var date: String
    var type: String
    var startTime = ""
    var endTime = ""
    var title = ""
    var color: Int64 = 4_289_368_575 // #FFAA91FF
    var note = ""
    var breakMinutes = 0
    var updatedAt: Int64 = 0
    var sourceDevice = ""
    var deleted = false
    var id: String { date }
}

struct ShiftType: Codable, Identifiable {
    var id: String
    var name: String
    var color: Int64
    var updatedAt: Int64 = 0
    var deleted = false
}

struct CalendarSnapshot: Codable {
    var version = 1
    var deviceId: String
    var config: ShiftConfig
    var overrides: [ShiftEntry]
    var customTypes: [ShiftType]
}

@MainActor final class CalendarModel: ObservableObject {
    @Published var month = Calendar.current.dateInterval(of: .month, for: .now)!.start
    @Published var selected = Date()
    @Published var config = ShiftConfig()
    @Published var overrides: [String: ShiftEntry] = [:]
    @Published var customTypes: [ShiftType] = []
    @Published var partner: CalendarSnapshot?
    @Published var pairedId: String?
    @Published var qrText: String?
    @Published var status = "Готово к работе"
    @Published var busy = false
    @Published var showingPartner = false
    let deviceId: String
    private let sync = LocalSync()
    private let defaults = UserDefaults.standard

    init() {
        deviceId = defaults.string(forKey: "device_id") ?? UUID().uuidString.lowercased()
        defaults.set(deviceId, forKey: "device_id")
        pairedId = defaults.string(forKey: "paired_device_id")
        if let data = defaults.data(forKey: "own_snapshot"), let value = try? JSONDecoder().decode(CalendarSnapshot.self, from: data) {
            config = value.config; overrides = Dictionary(uniqueKeysWithValues: value.overrides.filter { !$0.deleted }.map { ($0.date, $0) }); customTypes = value.customTypes.filter { !$0.deleted }
        }
        else if let data = try? JSONEncoder().encode(CalendarSnapshot(deviceId: deviceId, config: config, overrides: [], customTypes: [])) { defaults.set(data, forKey:"own_snapshot") }
        if let data = defaults.data(forKey: "partner_snapshot") { partner = try? JSONDecoder().decode(CalendarSnapshot.self, from: data) }
        sync.onStatus = { [weak self] text, loading in Task { @MainActor in self?.status = text; self?.busy = loading } }
        sync.onPartnerSnapshot = { [weak self] snapshot in Task { @MainActor in self?.setPartner(snapshot) } }
        sync.onPaired = { [weak self] id in Task { @MainActor in self?.pairedId = id } }
        if pairedId != nil { Task { await sync.startPairedHost(deviceId: deviceId) } }
    }

    func moveMonth(_ amount: Int) { month = Calendar.current.date(byAdding: .month, value: amount, to: month) ?? month }
    func saveConfiguration() { config.updatedAt = Int64(Date().timeIntervalSince1970 * 1000); config.sourceDevice = deviceId; persistAndPublish() }
    func dayType(_ date: Date, partnerMode: Bool = false) -> (String, String, Int64) {
        let key = Self.dayKey(date)
        let snap = partnerMode ? partner : nil
        let cfg = snap?.config ?? config
        if partnerMode {
            if let entry = snap?.overrides.first(where: { $0.date == key && !$0.deleted }) { return (entry.title.isEmpty ? label(entry.type) : entry.title, entry.startTime, entry.color) }
        } else if let entry = overrides[key] {
            return (entry.title.isEmpty ? label(entry.type) : entry.title, entry.startTime, entry.color)
        }
        let formatter = DateFormatter(); formatter.locale = Locale(identifier:"en_US_POSIX"); formatter.timeZone = TimeZone.current; formatter.dateFormat = "yyyy-MM-dd"
        let anchor = formatter.date(from: cfg.anchorDate) ?? Date()
        let d0 = Calendar(identifier: .gregorian).startOfDay(for: anchor)
        let d1 = Calendar(identifier: .gregorian).startOfDay(for: date)
        let days = Calendar(identifier: .gregorian).dateComponents([.day], from: d0, to: d1).day ?? 0
        let cycle = max(1, cfg.workDays + cfg.restDays)
        let phase = (days % cycle + cycle) % cycle
        return phase < cfg.workDays ? ("Смена", cfg.startTime, cfg.accent) : ("Выходной", "", 4_282_121_769)
    }
    func setType(_ type: String, on date: Date, color: Int64? = nil) {
        let entry = ShiftEntry(date: Self.dayKey(date), type: type, startTime: type == "WORK" || type == "EXTRA" ? config.startTime : "", endTime: type == "WORK" || type == "EXTRA" ? config.endTime : "", title: "", color: color ?? config.accent, updatedAt: Int64(Date().timeIntervalSince1970 * 1000), sourceDevice: deviceId)
        overrides[entry.date] = entry; persistAndPublish()
    }
    func startPairing() { Task { await sync.startPairing(deviceId: deviceId) } }
    func join(qr: String) { Task { await sync.join(qr: qr, deviceId: deviceId) } }
    func refresh() { Task { await sync.refresh(deviceId: deviceId, pairedId: pairedId, own: snapshot()) } }
    func disconnect() { sync.disconnect(); pairedId = nil; partner = nil; defaults.removeObject(forKey: "paired_device_id"); defaults.removeObject(forKey: "paired_secret"); defaults.removeObject(forKey: "partner_snapshot"); status = "Связь разорвана" }

    func snapshot() -> CalendarSnapshot { CalendarSnapshot(deviceId: deviceId, config: config, overrides: Array(overrides.values), customTypes: customTypes) }
    private func persistAndPublish() {
        if let data = try? JSONEncoder().encode(snapshot()) { defaults.set(data, forKey: "own_snapshot") }
    }
    private func setPartner(_ snap: CalendarSnapshot) {
        partner = snap
        if let data = try? JSONEncoder().encode(snap) { defaults.set(data, forKey: "partner_snapshot") }
    }
    static func dayKey(_ date: Date) -> String { let f = DateFormatter(); f.calendar = Calendar(identifier: .gregorian); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone.current; f.dateFormat = "yyyy-MM-dd"; return f.string(from: date) }
    private func label(_ type: String) -> String { ["WORK":"Смена", "REST":"Выходной", "EXTRA":"Доп. смена", "VACATION":"Отпуск", "SICK":"Больничный", "STUDY":"Учёба", "OTHER":"Другое"][type] ?? type }
}

private final class LocalSync: @unchecked Sendable {
    private let queue = DispatchQueue(label: "nox.sync.network")
    private var listener: NWListener?
    private var browser: NWBrowser?
    private var serviceName = ""
    private var secret = ""
    private var expectedPeer: String?
    var onStatus: ((String, Bool) -> Void)?
    var onPartnerSnapshot: ((CalendarSnapshot) -> Void)?
    var onPaired: ((String?) -> Void)?

    func startPairing(deviceId: String) async {
        let key = Data((0..<32).map { _ in UInt8.random(in: 0...255) }).base64EncodedString()
        do {
            try await host(deviceId: deviceId, secret: key, showQR: true)
            let qr: [String: Any] = ["app":"nox-calendar", "version":2, "service":serviceName, "device":deviceId, "secret":key]
            let data = try JSONSerialization.data(withJSONObject: qr)
            NotificationCenter.default.post(name: .noxQrReady, object: String(data: data, encoding: .utf8))
        } catch { onStatus?("Не удалось открыть сеанс: \(error.localizedDescription)", false) }
    }
    func startPairedHost(deviceId: String) async {
        guard let key = UserDefaults.standard.string(forKey: "paired_secret") else { return }
        try? await host(deviceId: deviceId, secret: key, showQR: false)
    }
    private func host(deviceId: String, secret: String, showQR: Bool) async throws {
        listener?.cancel(); self.secret = secret; expectedPeer = UserDefaults.standard.string(forKey: "paired_device_id")
        let l = try NWListener(using: .tcp)
        let name = "NoxCalendar-\(deviceId)"; serviceName = name
        l.service = NWListener.Service(name: name, type: "_noxcal._tcp")
        l.newConnectionHandler = { [weak self] connection in Task { await self?.serve(connection) } }
        l.start(queue: queue); listener = l
        onStatus?(showQR ? "Ожидаю подключения по QR" : "Связанный телефон доступен", false)
    }
    private func serve(_ connection: NWConnection) async {
        connection.start(queue: queue)
        do {
            let salt = Data((0..<16).map { _ in UInt8.random(in: 0...255) })
            try await sendLine(connection, object: ["salt":salt.base64EncodedString()])
            let request = try await receiveLine(connection)
            let key = try makeKey(secret, salt: salt)
            let remote = try decrypt(request, key: key)
            let remoteId = remote.deviceId
            guard !remoteId.isEmpty, expectedPeer == nil || remoteId == expectedPeer else { throw SyncError.peerMismatch }
            await MainActor.run { onPartnerSnapshot?(remote) }
            expectedPeer = remoteId
            UserDefaults.standard.set(remoteId, forKey: "paired_device_id"); UserDefaults.standard.set(secret, forKey: "paired_secret")
            await MainActor.run { onPaired?(remoteId) }
            let own = try JSONEncoder().encode(remoteOwnSnapshot())
            try await sendLine(connection, object: try encrypt(own, key: key))
            onStatus?("Календарь напарника обновлён", false)
        } catch { onStatus?("Синхронизация не выполнена: \(error.localizedDescription)", false) }
        connection.cancel()
    }
    private func remoteOwnSnapshot() -> CalendarSnapshot { // own snapshot is supplied by the facade via persisted current state
        if let data = UserDefaults.standard.data(forKey: "own_snapshot"), let value = try? JSONDecoder().decode(CalendarSnapshot.self, from: data) { return value }
        return CalendarSnapshot(deviceId: UserDefaults.standard.string(forKey: "device_id") ?? "", config: ShiftConfig(), overrides: [], customTypes: [])
    }
    func join(qr: String, deviceId: String) async {
        guard let data = qr.data(using: .utf8), let value = try? JSONSerialization.jsonObject(with: data) as? [String:Any], value["app"] as? String == "nox-calendar", value["version"] as? Int == 2, let service = value["service"] as? String, let peer = value["device"] as? String, let pin = value["secret"] as? String else { onStatus?("Неверный QR-код Nox Calendar", false); return }
        expectedPeer = peer; secret = pin; UserDefaults.standard.set(pin, forKey: "pending_secret")
        await browse(target: service, deviceId: deviceId, pairedId: peer)
    }
    func refresh(deviceId: String, pairedId: String?, own: CalendarSnapshot) async {
        if let id = pairedId, let key = UserDefaults.standard.string(forKey: "paired_secret") { secret = key; await browse(target: "NoxCalendar-\(id)", deviceId: deviceId, pairedId: id) }
        else { onStatus?("Сначала свяжите телефон по QR-коду", false) }
    }
    private func browse(target: String, deviceId: String, pairedId: String) async {
        browser?.cancel(); onStatus?("Ищу связанный телефон…", true)
        let b = NWBrowser(for: .bonjour(type: "_noxcal._tcp", domain: nil), using: .tcp)
        b.browseResultsChangedHandler = { [weak self] results, _ in
            guard let result = results.first(where: { if case let .service(name,_,_,_) = $0.endpoint { return name == target }; return false }), case let .service(name, type, domain, interface) = result.endpoint else { return }
            b.cancel()
            let connection = NWConnection(to: .service(name: name, type: type, domain: domain, interface: interface), using: .tcp)
            Task { await self?.exchange(connection, deviceId: deviceId, peerId: pairedId) }
        }
        b.stateUpdateHandler = { [weak self] state in if case .failed(let error) = state { Task { await self?.report(error.localizedDescription) } } }
        b.start(queue: queue); browser = b
        try? await Task.sleep(for: .seconds(25)); if browser === b { b.cancel(); browser = nil; onStatus?("Телефон не найден в этой Wi‑Fi сети", false) }
    }
    private func exchange(_ connection: NWConnection, deviceId: String, peerId: String) async {
        connection.start(queue: queue)
        do {
            let hello = try await receiveLine(connection)
            guard let saltText = hello["salt"] as? String, let salt = Data(base64Encoded: saltText) else { throw SyncError.badData }
            let key = try makeKey(secret, salt: salt)
            let own = remoteOwnSnapshot()
            try await sendLine(connection, object: try encrypt(try JSONEncoder().encode(own), key: key))
            let reply = try await receiveLine(connection)
            if let error = reply["error"] as? String { throw SyncError.message(error) }
            let other = try decrypt(reply, key: key)
            guard other.deviceId == peerId else { throw SyncError.peerMismatch }
            await MainActor.run { onPartnerSnapshot?(other) }
            UserDefaults.standard.set(peerId, forKey: "paired_device_id"); UserDefaults.standard.set(secret, forKey: "paired_secret"); UserDefaults.standard.removeObject(forKey: "pending_secret")
            await MainActor.run { onPaired?(peerId) }
            if listener == nil { await startPairedHost(deviceId: deviceId) }
            onStatus?("Календарь напарника обновлён", false)
        } catch { onStatus?("Синхронизация не выполнена: \(error.localizedDescription)", false) }
        connection.cancel()
    }
    func disconnect() { listener?.cancel(); listener = nil; browser?.cancel(); browser = nil; secret = "" }
    private func report(_ value: String) { onStatus?(value, false) }

    private func sendLine(_ connection: NWConnection, object: [String:Any]) async throws {
        var data = try JSONSerialization.data(withJSONObject: object); data.append(10)
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in connection.send(content: data, completion: .contentProcessed { error in if let error { continuation.resume(throwing:error) } else { continuation.resume() } }) }
    }
    private func receiveLine(_ connection: NWConnection) async throws -> [String:Any] {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<[String:Any], Error>) in
            var accumulated = Data()
            func receiveNext() {
                connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, done, error in
                    if let error { continuation.resume(throwing:error); return }
                    if let data { accumulated.append(data) }
                    if let index = accumulated.firstIndex(of: 10) {
                        do { let value = try JSONSerialization.jsonObject(with: accumulated[..<index]) as? [String:Any] ?? [:]; continuation.resume(returning:value) }
                        catch { continuation.resume(throwing:error) }
                    } else if done { continuation.resume(throwing:SyncError.badData) }
                    else { receiveNext() }
                }
            }
            receiveNext()
        }
    }
    private func makeKey(_ password: String, salt: Data) throws -> SymmetricKey {
        let pass = Array(password.utf8); var output = [UInt8](repeating:0, count:32)
        let result: Int32 = pass.withUnsafeBufferPointer { passBuffer in salt.withUnsafeBytes { saltBuffer in output.withUnsafeMutableBufferPointer { outputBuffer in
            CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), UnsafeRawPointer(passBuffer.baseAddress!).assumingMemoryBound(to:Int8.self), pass.count, saltBuffer.baseAddress!.assumingMemoryBound(to:UInt8.self), salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), 120_000, outputBuffer.baseAddress!, output.count)
        } } }
        guard result == kCCSuccess else { throw SyncError.badData }; return SymmetricKey(data:Data(output))
    }
    private func encrypt(_ plaintext: Data, key: SymmetricKey) throws -> [String:String] {
        let box = try AES.GCM.seal(plaintext, using:key)
        return ["nonce":box.nonce.withUnsafeBytes { Data($0).base64EncodedString() }, "data":(box.ciphertext + box.tag).base64EncodedString()]
    }
    private func decrypt(_ object: [String:Any], key: SymmetricKey) throws -> CalendarSnapshot {
        guard let n = object["nonce"] as? String, let d = object["data"] as? String, let nonce = Data(base64Encoded:n), let combined = Data(base64Encoded:d), combined.count >= 16 else { throw SyncError.badData }
        let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data:nonce), ciphertext:Data(combined.dropLast(16)), tag:Data(combined.suffix(16)))
        return try JSONDecoder().decode(CalendarSnapshot.self, from:AES.GCM.open(box, using:key))
    }
}

enum SyncError: Error, LocalizedError { case badData, peerMismatch, message(String); var errorDescription: String? { switch self { case .badData:return "Повреждённые данные"; case .peerMismatch:return "Подключился другой телефон"; case .message(let text):return text } } }
extension Notification.Name { static let noxQrReady = Notification.Name("nox.qr.ready") }
