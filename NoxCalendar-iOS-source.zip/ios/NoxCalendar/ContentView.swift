import SwiftUI
import CoreImage.CIFilterBuiltins
import AVFoundation
import UIKit

private let purple = Color(red: 0.67, green: 0.57, blue: 1)
private let card = Color(red: 0.11, green: 0.11, blue: 0.15)

struct ContentView: View {
    @EnvironmentObject private var model: CalendarModel
    @State private var showingScanner = false
    @State private var showQR = false
    @State private var activeTab = 0
    @State private var selectedType = "WORK"
    private let week = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]
    private let df: DateFormatter = { let f = DateFormatter(); f.locale = Locale(identifier:"ru_RU"); f.dateFormat = "LLLL yyyy"; return f }()

    var body: some View {
        VStack(spacing: 0) {
            if activeTab == 0 { calendarPage } else if activeTab == 1 { statsPage } else { settingsPage }
            HStack {
                nav("calendar", "Календарь", 0)
                nav("chart.bar.xaxis", "Статистика", 1)
                nav("gearshape.fill", "Настройки", 2)
            }.padding(.top, 9).padding(.bottom, 5).background(card)
        }
        .background(Color(red:0.06, green:0.06, blue:0.08).ignoresSafeArea())
        .onReceive(NotificationCenter.default.publisher(for: .noxQrReady)) { note in if let value = note.object as? String { qrValue = value; showQR = true } }
        .sheet(isPresented: $showingScanner) { QRScanner { value in showingScanner = false; if let value { model.join(qr:value) } } }
        .sheet(isPresented: $showQR) { qrSheet }
    }

    private var calendarPage: some View {
        VStack(spacing: 7) {
            HStack {
                Text(model.showingPartner ? "Календарь напарника" : "Nox Calendar").font(.system(size:24, weight:.bold)).foregroundStyle(purple).lineLimit(1)
                Spacer()
                if model.pairedId != nil { Button { model.refresh() } label: { Image(systemName:"arrow.clockwise").rotationEffect(.degrees(model.busy ? 360 : 0)).animation(model.busy ? .linear(duration:0.8).repeatForever(autoreverses:false) : .default, value:model.busy).foregroundStyle(purple).font(.title2) }.disabled(model.busy) }
            }.padding(.horizontal,16).padding(.top,8)
            HStack {
                Button { model.moveMonth(-1) } label: { Image(systemName:"chevron.left") }
                Spacer()
                Text(df.string(from:model.month).capitalized).font(.title3).foregroundStyle(.white)
                Spacer()
                Button { model.moveMonth(1) } label: { Image(systemName:"chevron.right") }
            }.font(.title2).foregroundStyle(purple).padding(.horizontal,18).padding(.vertical,4)
            HStack(spacing:0) { ForEach(week, id:\.self) { Text($0).font(.caption).foregroundStyle(.gray).frame(maxWidth:.infinity) } }
            let dates = monthDays
            LazyVGrid(columns:Array(repeating:GridItem(.flexible(), spacing:4), count:7), spacing:4) {
                ForEach(Array(dates.enumerated()), id:\.offset) { element in
                    let date = element.element
                    if let date {
                        let day = model.dayType(date, partnerMode:model.showingPartner)
                        Button {
                            if !model.showingPartner { model.selected = date; model.setType(selectedType, on:date) }
                        } label: {
                            VStack(alignment:.leading, spacing:5) {
                                Text("\(Calendar.current.component(.day, from:date))").frame(maxWidth:.infinity, alignment:.trailing).foregroundStyle(.white)
                                Text(day.0).font(.system(size:10)).lineLimit(2).frame(maxWidth:.infinity, alignment:.leading).foregroundStyle(.white.opacity(0.9))
                                Text(day.1).font(.system(size:9)).foregroundStyle(purple)
                                Spacer(minLength:0)
                            }.padding(5).frame(maxWidth:.infinity, maxHeight:.infinity, alignment:.topLeading).background(argbColor(day.2).opacity(0.24), in:RoundedRectangle(cornerRadius:9)).overlay(RoundedRectangle(cornerRadius:9).stroke(Color.white.opacity(0.12), lineWidth:0.5))
                        }.buttonStyle(.plain).disabled(model.showingPartner)
                    } else { Color.clear }
                }
            }.padding(.horizontal,12).frame(maxHeight:.infinity)
            HStack(spacing:5) {
                tabButton("Мой календарь", selected:!model.showingPartner, enabled:true) { model.showingPartner = false }
                tabButton("Напарник", selected:model.showingPartner, enabled:model.partner != nil) { model.showingPartner = true }
            }.padding(4).background(card, in:RoundedRectangle(cornerRadius:14)).padding(.horizontal,14)
            if model.showingPartner { Text("Только просмотр").font(.caption).foregroundStyle(.gray).padding(.top,2) }
            else {
                HStack(spacing:8) {
                    let shiftChoices = [("WORK","Смена",Int64(0xFFAA91FF)), ("REST","Выходной",Int64(0xFF44434E)), ("EXTRA","Доп. смена",Int64(0xFFFFA76B)), ("VACATION","Отпуск",Int64(0xFF62D6B0))]
                    ForEach(shiftChoices.indices, id:\.self) { index in
                        let item = shiftChoices[index]
                        Button { selectedType = item.0 } label: { Text(item.1).font(.caption2).lineLimit(1).padding(.horizontal,8).padding(.vertical,11).frame(maxWidth:.infinity).background(argbColor(item.2).opacity(selectedType == item.0 ? 0.55 : 0.28), in:RoundedRectangle(cornerRadius:11)) }
                    }
                }.padding(.horizontal,13)
            }
            Spacer(minLength:4)
        }.padding(.top,4).gesture(DragGesture(minimumDistance:30).onEnded { value in if abs(value.translation.width) > 70 { model.moveMonth(value.translation.width < 0 ? 1 : -1) } })
    }

    private var statsPage: some View {
        VStack(spacing:14) {
            Text("Статистика").font(.largeTitle.bold()).foregroundStyle(.white).frame(maxWidth:.infinity, alignment:.leading)
            HStack { Button { model.moveMonth(-1) } label:{Image(systemName:"chevron.left")}; Spacer(); Text(df.string(from:model.month).capitalized); Spacer(); Button { model.moveMonth(1) } label:{Image(systemName:"chevron.right")} }.foregroundStyle(purple)
            let values = monthDates.compactMap { $0 }.map { model.dayType($0) }
            stat("Смен", "\(values.filter{$0.0 == "Смена" || $0.0 == "Доп. смена"}.count)")
            stat("Выходных", "\(values.filter{$0.0 == "Выходной"}.count)")
            stat("Рабочих часов", "\(values.filter{$0.0 == "Смена"}.count * 10) ч")
            Spacer()
        }.padding(20).gesture(DragGesture(minimumDistance:30).onEnded { value in if abs(value.translation.width)>70 { model.moveMonth(value.translation.width < 0 ? 1 : -1) } })
    }

    private var settingsPage: some View {
        ScrollView {
            VStack(alignment:.leading, spacing:16) {
                Text("Настройки").font(.largeTitle.bold()).foregroundStyle(.white)
                Text("ГРАФИК").font(.caption.bold()).foregroundStyle(.gray)
                HStack { field("Смен", value:$model.config.workDays); field("Выходных", value:$model.config.restDays) }
                HStack { field("Начало", value:$model.config.startTime); field("Конец", value:$model.config.endTime) }
                TextField("Первая смена (ГГГГ-ММ-ДД)", text:$model.config.anchorDate).padding(12).background(card,in:RoundedRectangle(cornerRadius:12))
                Button("Сохранить график") { model.saveConfiguration() }.buttonStyle(.borderedProminent).tint(purple)
                Text("Синхронизация по Wi‑Fi").font(.headline).foregroundStyle(.white).padding(.top,12)
                Text(model.status).font(.caption).foregroundStyle(purple)
                if let id = model.pairedId { Text("Связано с телефоном · \(id.prefix(8))").foregroundStyle(.white) }
                if model.pairedId == nil {
                    HStack { Button("Показать QR") { model.startPairing() }.buttonStyle(.borderedProminent); Button("Сканировать QR") { showingScanner = true }.buttonStyle(.bordered) }
                } else { Button("Разорвать связь", role:.destructive) { model.disconnect() }.buttonStyle(.bordered) }
                Text("Оба телефона должны быть открыты в одной Wi‑Fi сети. Календари остаются отдельными.").font(.caption).foregroundStyle(.gray)
            }.padding(20)
        }
    }

    private var monthDates:[Date?] {
        let cal = Calendar.current, start = cal.dateInterval(of:.month, for:model.month)!.start
        let count = cal.range(of:.day, in:.month, for:start)!.count
        let weekday = (cal.component(.weekday, from:start) + 5) % 7
        return Array(repeating:nil, count:weekday) + (0..<count).compactMap { cal.date(byAdding:.day, value:$0, to:start) as Date? }
    }
    private var monthDays:[Date?] { let vals=monthDates; let rows=(vals.count+6)/7; return vals + Array(repeating:nil, count:rows*7-vals.count) }
    private func nav(_ icon:String, _ title:String, _ tab:Int)->some View { Button { activeTab=tab } label:{ VStack(spacing:4){Image(systemName:icon).font(.title3);Text(title).font(.caption)}.foregroundStyle(activeTab==tab ? purple : .white.opacity(0.7)).frame(maxWidth:.infinity) } }
    private func tabButton(_ title:String, selected:Bool, enabled:Bool, action:@escaping()->Void)->some View { Button(action:action){Text(title).font(.caption).foregroundStyle(selected ? purple : .gray).frame(maxWidth:.infinity).padding(.vertical,9).background(selected ? purple.opacity(0.18) : .clear, in:RoundedRectangle(cornerRadius:10))}.disabled(!enabled) }
    private func stat(_ name:String,_ value:String)->some View { HStack { Text(name).foregroundStyle(.gray); Spacer(); Text(value).font(.title2.bold()).foregroundStyle(purple) }.padding(15).background(card, in:RoundedRectangle(cornerRadius:16)) }
    private func field(_ title:String,value:Binding<Int>)->some View { TextField(title,value:value,format:.number).keyboardType(.numberPad).padding(12).background(card,in:RoundedRectangle(cornerRadius:12)) }
    private func field(_ title:String,value:Binding<String>)->some View { TextField(title,text:value).padding(12).background(card,in:RoundedRectangle(cornerRadius:12)) }
    private var qrSheet: some View {
        VStack(spacing:18) { Text("Связать телефон").font(.title2.bold()); if let value=qrValue, let image=qrImage(value) { Image(uiImage:image).interpolation(.none).resizable().scaledToFit().frame(width:250,height:250).padding().background(.white,in:RoundedRectangle(cornerRadius:18)) }; Text("Отсканируй этот код на Android‑телефоне в настройках синхронизации.").multilineTextAlignment(.center).foregroundStyle(.secondary); Button("Готово") { showQR=false }.buttonStyle(.borderedProminent) }.padding(24).presentationDetents([.medium,.large])
    }
    @State private var qrValue:String?
    private func qrImage(_ text:String)->UIImage? { let filter=CIFilter.qrCodeGenerator(); filter.message=Data(text.utf8); filter.correctionLevel="M"; guard let output=filter.outputImage, let cg=CIContext().createCGImage(output.transformed(by:CGAffineTransform(scaleX:8,y:8)), from:output.extent.applying(CGAffineTransform(scaleX:8,y:8))) else{return nil}; return UIImage(cgImage:cg) }
}

private func argbColor(_ value:Int64)->Color {
    let bits=UInt32(truncatingIfNeeded:value)
    return Color(.sRGB, red:Double((bits>>16)&255)/255, green:Double((bits>>8)&255)/255, blue:Double(bits&255)/255, opacity:Double((bits>>24)&255)/255)
}

private struct QRScanner: UIViewControllerRepresentable {
    var onResult:(String?)->Void
    func makeUIViewController(context:Context)->ScannerController { let vc=ScannerController(); vc.onResult=onResult; return vc }
    func updateUIViewController(_ uiViewController:ScannerController, context:Context) {}
}
private final class ScannerController:UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onResult:((String?)->Void)?; private let session=AVCaptureSession()
    override func viewDidLoad() { super.viewDidLoad(); view.backgroundColor=.black
        guard let device=AVCaptureDevice.default(for:.video), let input=try? AVCaptureDeviceInput(device:device), session.canAddInput(input) else { onResult?(nil); return }
        let output=AVCaptureMetadataOutput(); guard session.canAddOutput(output) else { onResult?(nil); return }; session.addInput(input); session.addOutput(output); output.setMetadataObjectsDelegate(self, queue:.main); output.metadataObjectTypes=[.qr]
        let preview=AVCaptureVideoPreviewLayer(session:session); preview.videoGravity = .resizeAspectFill; preview.frame=view.bounds; view.layer.addSublayer(preview); session.startRunning()
    }
    func metadataOutput(_ output:AVCaptureMetadataOutput,didOutput metadataObjects:[AVMetadataObject],from connection:AVCaptureConnection) { if let value=metadataObjects.first as? AVMetadataMachineReadableCodeObject, let text=value.stringValue { session.stopRunning(); onResult?(text) } }
}
