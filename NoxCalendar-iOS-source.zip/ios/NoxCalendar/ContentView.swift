import SwiftUI
import CoreImage.CIFilterBuiltins
import AVFoundation
import UIKit

private let violet = Color(red: 0.67, green: 0.57, blue: 1)
private let panel = Color(red: 0.11, green: 0.11, blue: 0.15)
private let muted = Color(red: 0.55, green: 0.54, blue: 0.60)
private let dayTypes: [(String, String, Int64)] = [
    ("WORK", "Смена", 0xFFAA91FF), ("REST", "Выходной", 0xFF44434E),
    ("EXTRA", "Доп. смена", 0xFFFFA76B), ("VACATION", "Отпуск", 0xFF62D6B0),
    ("SICK", "Больничный", 0xFFFF7185), ("STUDY", "Учёба", 0xFF6DC9E9), ("OTHER", "Другое", 0xFFB0A7C7)
]
private let palette: [Int64] = [0xFFAA91FF,0xFF8066E8,0xFF5842B8,0xFF69B9FF,0xFF3478D4,0xFF62D6B0,0xFF278F75,0xFFFFA76B,0xFFE27B37,0xFFFF7185,0xFFD64262,0xFFD38AF0,0xFF9C4EC1,0xFFFFD166,0xFF9AA0AA,0xFFEEEEF2]

struct ContentView: View {
    @EnvironmentObject private var model: CalendarModel
    @State private var page = 0
    @State private var selectedType: String?
    @State private var selectedCustom: ShiftType?
    @State private var editorEntry: ShiftEntry?
    @State private var showScanner = false
    @State private var showQR = false
    @State private var qrValue: String?
    @State private var toast: String?
    @State private var customName = ""
    @State private var customColor: Int64 = palette[0]
    private let week = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]
    private var monthTitle: String { let f = DateFormatter(); f.locale = Locale(identifier: "ru_RU"); f.dateFormat = "LLLL yyyy"; return f.string(from: model.month).capitalized }
    private var isDarkDoodles: Bool { model.backgroundStyle == 2 }

    var body: some View {
        ZStack {
            background.ignoresSafeArea()
            VStack(spacing: 0) {
                Group { if page == 0 { calendarPage } else if page == 1 { statsPage } else { settingsPage } }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                bottomBar
            }
            if let toast { VStack { Spacer(); Text(toast).font(.subheadline.weight(.medium)).foregroundStyle(.white).padding(.horizontal, 18).padding(.vertical, 12).background(panel, in: Capsule()).padding(.bottom, 82) }.transition(.move(edge: .bottom).combined(with: .opacity)) }
        }
        .preferredColorScheme(.dark)
        .sheet(item: $editorEntry) { entry in
            DayEditor(entry: entry, config: model.config, customTypes: model.customTypes, accent: accent, onSave: { model.saveDay($0); editorEntry = nil }, onReset: { model.resetDay(dateFromKey(entry.date)); editorEntry = nil })
        }
        .sheet(isPresented: $showScanner) { QRScanner { code in showScanner = false; if let code { model.join(qr: code) } } }
        .sheet(isPresented: $showQR) { qrSheet }
        .onReceive(NotificationCenter.default.publisher(for: .noxQrReady)) { n in
            if let value = n.object as? String { qrValue = value; showQR = true }
        }
        .onChange(of: model.status) { value in
            if !value.isEmpty { withAnimation { toast = value }; DispatchQueue.main.asyncAfter(deadline: .now() + 3) { withAnimation { toast = nil } } }
        }
    }

    private var background: some View {
        ZStack {
            Color(red: 0.055, green: 0.055, blue: 0.075)
            if model.backgroundStyle == 1 { Color.black }
            if isDarkDoodles, let image = UIImage(contentsOfFile: Bundle.main.path(forResource: "bg_doodles", ofType: "png") ?? "") {
                Image(uiImage: image).resizable().scaledToFill().opacity(0.42)
            }
        }
    }
    private var accent: Color { color(model.config.accent) }
    private var bottomBar: some View {
        HStack {
            navIcon("calendar", tab: 0)
            navIcon("chart.bar.xaxis", tab: 1)
            navIcon("gearshape.fill", tab: 2)
        }.padding(.horizontal, 24).padding(.top, 11).padding(.bottom, 7).background(panel.opacity(0.97))
    }
    private func navIcon(_ symbol: String, tab: Int) -> some View {
        Button { page = tab } label: {
            Image(systemName: symbol).font(.system(size: 21, weight: .semibold))
                .foregroundStyle(page == tab ? accent : Color.white.opacity(0.68))
                .frame(maxWidth: .infinity).frame(height: 44)
                .background(page == tab ? accent.opacity(0.16) : .clear, in: Capsule())
        }.buttonStyle(.plain)
    }

    private var calendarPage: some View {
        VStack(spacing: 6) {
            HStack(spacing: 12) {
                Text(model.showingPartner ? "Календарь напарника" : "Nox Calendar")
                    .font(.system(size: 25, weight: .bold)).foregroundStyle(accent).lineLimit(1)
                Spacer(minLength: 0)
                if model.pairedId != nil {
                    Button { model.refresh() } label: {
                        Image(systemName: "arrow.clockwise").font(.title3.weight(.semibold)).foregroundStyle(accent)
                            .rotationEffect(.degrees(model.busy ? 360 : 0)).animation(model.busy ? .linear(duration: 0.8).repeatForever(autoreverses: false) : .default, value: model.busy)
                    }.disabled(model.busy).accessibilityLabel("Обновить синхронизацию")
                }
            }.padding(.horizontal, 18).padding(.top, 8)

            HStack {
                Button { model.moveMonth(-1) } label: { Image(systemName: "chevron.left") }
                Spacer()
                Button { withAnimation(.easeInOut(duration: 0.25)) { model.month = Calendar.current.dateInterval(of: .month, for: Date())!.start; model.selected = Date() } } label: { Text(monthTitle).font(.system(size: 22, weight: .medium)).foregroundStyle(.white) }
                Spacer()
                Button { model.moveMonth(1) } label: { Image(systemName: "chevron.right") }
            }.font(.title3).foregroundStyle(accent).padding(.horizontal, 20).padding(.vertical, 3)

            HStack(spacing: 0) { ForEach(week, id: \.self) { Text($0).font(.caption.weight(.medium)).foregroundStyle(muted).frame(maxWidth: .infinity).padding(.vertical, 4) } }
            calendarGrid.frame(maxHeight: .infinity)

            HStack(spacing: 6) {
                Button { model.showingPartner = false } label: { Text("Мой календарь").foregroundStyle(model.showingPartner ? muted : accent) }
                    .frame(maxWidth: .infinity).padding(.vertical, 9).background(model.showingPartner ? .clear : accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 11))
                Button { if model.partner != nil { model.showingPartner = true } } label: { Text("Напарник").foregroundStyle(model.showingPartner ? accent : muted) }
                    .frame(maxWidth: .infinity).padding(.vertical, 9).background(model.showingPartner ? accent.opacity(0.16) : .clear, in: RoundedRectangle(cornerRadius: 11)).disabled(model.partner == nil)
            }.font(.subheadline).padding(4).background(panel, in: RoundedRectangle(cornerRadius: 14)).padding(.horizontal, 16)
            if model.showingPartner {
                Text("Только просмотр · календарь напарника").font(.caption).foregroundStyle(muted)
                selectedDayCard.padding(.horizontal, 16).disabled(true)
            } else {
                selectedDayCard.padding(.horizontal, 16)
                shiftPalette.padding(.horizontal, 12)
            }
        }
        .padding(.top, 4)
        .gesture(DragGesture(minimumDistance: 35).onEnded { v in if abs(v.translation.width) > 70 { model.moveMonth(v.translation.width < 0 ? 1 : -1) } })
    }

    private var calendarGrid: some View {
        let dates = visibleDates
        return LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 7), spacing: 4) {
            ForEach(Array(dates.enumerated()), id: \.offset) { item in
                if let date = item.element {
                    let entry = model.dayEntry(date, partnerMode: model.showingPartner)
                    dayCell(date, entry: entry)
                } else { Color.clear.frame(height: 1) }
            }
        }.padding(.horizontal, 12).contentShape(Rectangle())
    }
    private func dayCell(_ date: Date, entry: ShiftEntry) -> some View {
        let key = CalendarModel.dayKey(date)
        let inMonth = Calendar.current.component(.month, from: date) == Calendar.current.component(.month, from: model.month)
        let selected = key == CalendarModel.dayKey(model.selected)
        let today = key == CalendarModel.dayKey(Date())
        return VStack(alignment: .leading, spacing: 3) {
            Text("\(Calendar.current.component(.day, from: date))").font(.system(size: 14, weight: today ? .bold : .regular))
                .foregroundStyle(today ? Color.pink : (inMonth ? .white : muted.opacity(0.45))).frame(maxWidth: .infinity, alignment: .trailing)
            if entry.type != "REST" {
                Text(entry.title.isEmpty ? typeLabel(entry.type) : entry.title).font(.system(size: 9, weight: .medium)).lineLimit(2).foregroundStyle(inMonth ? .white.opacity(0.92) : muted.opacity(0.45))
                if !entry.startTime.isEmpty { Text(entry.startTime).font(.system(size: 8)).lineLimit(1).foregroundStyle(accent) }
            }
            Spacer(minLength: 0)
        }
        .padding(5).frame(maxWidth: .infinity).frame(height: 66, alignment: .topLeading)
        .background((inMonth ? tileColor(entry) : tileColor(entry).opacity(0.45)), in: RoundedRectangle(cornerRadius: 9))
        .overlay(RoundedRectangle(cornerRadius: 9).stroke(selected ? accent : (today ? Color.pink : Color.white.opacity(0.09)), lineWidth: selected || today ? 1.6 : 0.6))
        .contentShape(RoundedRectangle(cornerRadius: 9))
        .onTapGesture {
            guard !model.showingPartner else { model.selected = date; return }
            if let selectedType {
                let title = selectedCustom?.name ?? ""
                let type = selectedCustom.map { _ in "OTHER" } ?? selectedType
                model.fillDay(date, type: type, title: title, color: selectedCustom?.color ?? (type == "WORK" ? model.config.accent : defaultColor(for: type)))
            } else { model.selected = date; model.month = Calendar.current.dateInterval(of: .month, for: date)!.start }
        }
        .onLongPressGesture(minimumDuration: 0.45) {
            guard !model.showingPartner else { return }
            model.selected = date; editorEntry = model.dayEntry(date)
        }
    }

    private var selectedDayCard: some View {
        let entry = model.dayEntry(model.selected, partnerMode: model.showingPartner)
        let dateText: String = { let f = DateFormatter(); f.locale = Locale(identifier: "ru_RU"); f.dateFormat = "d MMMM, EEEE"; return f.string(from: model.selected) }()
        let worked = shiftHours(entry)
        return Button { editorEntry = entry } label: {
            HStack(spacing: 12) {
                Circle().fill(color(entry.color)).frame(width: 10, height: 10)
                VStack(alignment: .leading, spacing: 4) {
                    Text(dateText.capitalized).font(.subheadline).foregroundStyle(muted)
                    Text(entry.title.isEmpty ? typeLabel(entry.type) : entry.title).font(.headline).foregroundStyle(.white)
                    if !entry.startTime.isEmpty { Text("\(entry.startTime) — \(entry.endTime) · \(worked) ч").font(.subheadline).foregroundStyle(accent) }
                    if !entry.note.isEmpty { Text(entry.note).font(.caption).foregroundStyle(muted).lineLimit(2) }
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(muted)
            }.padding(13).frame(maxWidth: .infinity, alignment: .leading).background(panel, in: RoundedRectangle(cornerRadius: 18))
        }.buttonStyle(.plain)
    }

    private var shiftPalette: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(dayTypes.indices, id: \.self) { index in
                    let item = dayTypes[index]
                    paletteTile(id: item.0, name: item.1, color: item.2, custom: nil)
                }
                ForEach(model.customTypes.filter { !$0.deleted }) { custom in paletteTile(id: custom.id, name: custom.name, color: custom.color, custom: custom) }
            }.padding(.vertical, 2)
        }.frame(height: 58)
    }
    private func paletteTile(id: String, name: String, color: Int64, custom: ShiftType?) -> some View {
        let active: Bool
        if let custom { active = selectedCustom?.id == custom.id } else { active = selectedType == id && selectedCustom?.id == nil }
        return Button {
            if active { selectedType = nil; selectedCustom = nil }
            else { selectedType = id; selectedCustom = custom }
        } label: {
            VStack(spacing: 4) { Circle().fill(self.color(color)).frame(width: 8, height: 8); Text(name).font(.system(size: 10, weight: .medium)).lineLimit(2).multilineTextAlignment(.center).foregroundStyle(.white) }
                .frame(width: 70, height: 54).background(self.color(color).opacity(0.3), in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(active ? accent : Color.white.opacity(0.08), lineWidth: active ? 2 : 0.6))
        }.buttonStyle(.plain)
    }

    private var statsPage: some View {
        let days = monthDates
        let entries = days.map { model.dayEntry($0) }
        let work = entries.filter { ["WORK", "EXTRA"].contains($0.type) }
        return VStack(alignment: .leading, spacing: 12) {
            Text("Статистика").font(.system(size: 28, weight: .bold)).foregroundStyle(.white).padding(.top, 12)
            monthControls
            ScrollView {
                VStack(spacing: 9) {
                    statCard("Рабочие смены", "\(work.count)", "briefcase.fill", accent)
                    statCard("Выходные", "\(entries.filter { $0.type == "REST" }.count)", "moon.zzz.fill", muted)
                    statCard("Рабочие часы", "\(formatHours(entries.reduce(0) { $0 + shiftHours($1) })) ч", "clock.fill", accent)
                    statCard("Дополнительные смены", "\(entries.filter { $0.type == "EXTRA" }.count)", "plus.circle.fill", color(0xFFFFA76B))
                    statCard("Дни отпуска", "\(entries.filter { $0.type == "VACATION" }.count)", "sun.max.fill", color(0xFF62D6B0))
                    statCard("Средняя смена", "\(work.isEmpty ? "0" : formatHours(work.reduce(0) { $0 + shiftHours($1) } / Double(work.count))) ч", "chart.bar.fill", accent)
                }.padding(.bottom, 20)
            }
        }.padding(.horizontal, 18).gesture(monthSwipe)
    }
    private var monthControls: some View {
        HStack {
            Button { model.moveMonth(-1) } label: { Image(systemName: "chevron.left") }
            Spacer()
            Text(monthTitle).foregroundStyle(.white.opacity(0.86)).font(.headline)
            Spacer()
            Button { model.moveMonth(1) } label: { Image(systemName: "chevron.right") }
        }.font(.title3).foregroundStyle(accent).padding(.vertical, 6)
    }
    private func statCard(_ title: String, _ value: String, _ icon: String, _ tint: Color) -> some View {
        HStack(spacing: 12) { Image(systemName: icon).foregroundStyle(tint).frame(width: 24); Text(title).foregroundStyle(muted); Spacer(); Text(value).font(.title3.bold()).foregroundStyle(.white) }
            .padding(16).background(panel, in: RoundedRectangle(cornerRadius: 16))
    }

    private var settingsPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Настройки").font(.system(size: 28, weight: .bold)).foregroundStyle(.white)
                sectionTitle("ГРАФИК")
                VStack(alignment: .leading, spacing: 12) {
                    HStack { numberField("Рабочих", value: $model.config.workDays); numberField("Выходных", value: $model.config.restDays) }
                    TextField("Первая смена: ГГГГ-ММ-ДД", text: $model.config.anchorDate).textFieldStyle(.roundedBorder)
                    HStack { TextField("Начало", text: $model.config.startTime).textFieldStyle(.roundedBorder); TextField("Окончание", text: $model.config.endTime).textFieldStyle(.roundedBorder) }
                    Text("Шаблоны: 2/2 · 3/3 · 5/2 · 6/1 · 1/3 · свой цикл").font(.caption).foregroundStyle(muted)
                    HStack(spacing: 7) { ForEach(0..<5, id: \.self) { index in
                        let patterns = [(2,2),(3,3),(5,2),(6,1),(1,3)]; let (w,r) = patterns[index]
                        Button("\(w)/\(r)") { model.config.workDays = w; model.config.restDays = r }.buttonStyle(.bordered).tint(accent)
                    } }
                    Button("Сохранить график") { model.saveConfiguration(); notify("График сохранён") }.buttonStyle(.borderedProminent).tint(accent).frame(maxWidth: .infinity)
                }.padding(15).background(panel, in: RoundedRectangle(cornerRadius: 18))

                sectionTitle("ВНЕШНИЙ ВИД")
                VStack(alignment: .leading, spacing: 12) {
                    Text("Акцентный цвет").foregroundStyle(.white)
                    paletteRow(selection: model.config.accent) { model.setAccent($0) }
                    Text("Фон календаря").foregroundStyle(.white).padding(.top, 4)
                    HStack(spacing: 8) {
                        backgroundOption("Классика", style: 0)
                        backgroundOption("Чёрный", style: 1)
                        backgroundOption("Каракули", style: 2)
                    }
                }.padding(15).background(panel, in: RoundedRectangle(cornerRadius: 18))

                sectionTitle("СВОИ ТИПЫ СМЕН")
                VStack(alignment: .leading, spacing: 12) {
                    HStack { TextField("Название плитки", text: $customName).textFieldStyle(.roundedBorder); Button("Добавить") { model.addCustomType(name: customName, color: customColor); customName = "" }.disabled(customName.trimmingCharacters(in: .whitespaces).isEmpty).buttonStyle(.borderedProminent).tint(accent) }
                    paletteRow(selection: customColor) { customColor = $0 }
                    ForEach(model.customTypes.filter { !$0.deleted }) { item in HStack { Circle().fill(color(item.color)).frame(width: 11, height: 11); Text(item.name).foregroundStyle(.white); Spacer(); Button(role: .destructive) { model.removeCustomType(item.id) } label: { Image(systemName: "trash") } } }
                }.padding(15).background(panel, in: RoundedRectangle(cornerRadius: 18))

                sectionTitle("СИНХРОНИЗАЦИЯ")
                VStack(alignment: .leading, spacing: 11) {
                    Text(model.status).font(.subheadline).foregroundStyle(accent)
                    Text("Связь работает по одной Wi‑Fi сети. У каждого свой календарь; календарь напарника доступен для просмотра.").font(.caption).foregroundStyle(muted)
                    if model.pairedId == nil {
                        HStack { Button("Показать QR") { model.startPairing() }.buttonStyle(.borderedProminent).tint(accent); Button("Сканировать QR") { showScanner = true }.buttonStyle(.bordered).tint(accent) }
                    } else {
                        Text("Телефон напарника: \(model.pairedId!.prefix(8))").font(.caption).foregroundStyle(muted)
                        Button("Разорвать связь", role: .destructive) { model.disconnect() }.buttonStyle(.bordered)
                    }
                }.padding(15).background(panel, in: RoundedRectangle(cornerRadius: 18))
            }.padding(18)
        }
    }
    private func sectionTitle(_ text: String) -> some View { Text(text).font(.caption.weight(.bold)).tracking(1.2).foregroundStyle(muted) }
    private func numberField(_ title: String, value: Binding<Int>) -> some View { TextField(title, value: value, format: .number).keyboardType(.numberPad).textFieldStyle(.roundedBorder) }
    private func paletteRow(selection: Int64, set: @escaping (Int64) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) { HStack(spacing: 10) { ForEach(palette, id: \.self) { item in Circle().fill(color(item)).frame(width: 27, height: 27).overlay(Circle().stroke(selection == item ? .white : .clear, lineWidth: 2).padding(-3)).contentShape(Circle()).onTapGesture { set(item) } } }.padding(.vertical, 4) }
    }
    private func backgroundOption(_ title: String, style: Int) -> some View {
        Button { model.setBackground(style) } label: {
            VStack(spacing: 7) { RoundedRectangle(cornerRadius: 8).fill(style == 1 ? .black : Color(red:0.055, green:0.055, blue:0.075)).frame(height: 42).overlay { if style == 2 { Image(systemName: "scribble.variable").foregroundStyle(.white.opacity(0.25)) } }; Text(title).font(.caption).foregroundStyle(.white) }
                .padding(7).frame(maxWidth: .infinity).background(model.backgroundStyle == style ? accent.opacity(0.19) : .clear, in: RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(model.backgroundStyle == style ? accent : muted.opacity(0.3), lineWidth: 1))
        }.buttonStyle(.plain)
    }

    private var qrSheet: some View {
        VStack(spacing: 16) {
            Text("Связать телефон").font(.title2.bold()).foregroundStyle(.white)
            if let qrValue, let image = qrImage(qrValue) { Image(uiImage: image).interpolation(.none).resizable().scaledToFit().frame(width: 250, height: 250).padding(12).background(.white, in: RoundedRectangle(cornerRadius: 16)) }
            Text("На втором телефоне открой Nox Calendar → Настройки → Сканировать QR.").multilineTextAlignment(.center).foregroundStyle(muted)
            Button("Готово") { showQR = false }.buttonStyle(.borderedProminent).tint(accent)
        }.padding(24).presentationDetents([.medium, .large]).background(Color(red:0.07, green:0.07, blue:0.09))
    }

    private var visibleDates: [Date?] {
        let cal = Calendar.current
        let first = cal.dateInterval(of: .month, for: model.month)!.start
        let offset = (cal.component(.weekday, from: first) + 5) % 7
        let count = cal.range(of: .day, in: .month, for: first)!.count
        let days = (0..<count).compactMap { cal.date(byAdding: .day, value: $0, to: first) }
        let total = ((offset + count + 6) / 7) * 7
        return Array(repeating: nil, count: offset) + days.map(Optional.some) + Array(repeating: nil, count: max(0, total - offset - count))
    }
    private var monthDates: [Date] { let cal = Calendar.current; let first = cal.dateInterval(of: .month, for: model.month)!.start; return (0..<cal.range(of: .day, in: .month, for: first)!.count).compactMap { cal.date(byAdding: .day, value: $0, to: first) } }
    private var monthSwipe: some Gesture { DragGesture(minimumDistance: 35).onEnded { v in if abs(v.translation.width) > 70 { model.moveMonth(v.translation.width < 0 ? 1 : -1) } } }
    private func notify(_ text: String) { withAnimation { toast = text }; DispatchQueue.main.asyncAfter(deadline: .now() + 2) { withAnimation { toast = nil } } }
    private func qrImage(_ text: String) -> UIImage? { let f = CIFilter.qrCodeGenerator(); f.message = Data(text.utf8); f.correctionLevel = "M"; guard let out = f.outputImage else { return nil }; let scaled = out.transformed(by: CGAffineTransform(scaleX: 8, y: 8)); guard let cg = CIContext().createCGImage(scaled, from: scaled.extent) else { return nil }; return UIImage(cgImage: cg) }
}

private struct DayEditor: View {
    @Environment(\.dismiss) private var dismiss
    let entry: ShiftEntry
    let config: ShiftConfig
    let customTypes: [ShiftType]
    let accent: Color
    let onSave: (ShiftEntry) -> Void
    let onReset: () -> Void
    @State private var type: String
    @State private var start: String
    @State private var end: String
    @State private var title: String
    @State private var note: String
    @State private var pause: String
    @State private var selectedColor: Int64
    init(entry: ShiftEntry, config: ShiftConfig, customTypes: [ShiftType], accent: Color, onSave: @escaping (ShiftEntry) -> Void, onReset: @escaping () -> Void) {
        self.entry = entry; self.config = config; self.customTypes = customTypes; self.accent = accent; self.onSave = onSave; self.onReset = onReset
        _type = State(initialValue: entry.type); _start = State(initialValue: entry.startTime); _end = State(initialValue: entry.endTime); _title = State(initialValue: entry.title); _note = State(initialValue: entry.note); _pause = State(initialValue: String(entry.breakMinutes)); _selectedColor = State(initialValue: entry.color)
    }
    private var readableDate: String { let f = DateFormatter(); f.locale = Locale(identifier: "ru_RU"); f.dateFormat = "d MMMM yyyy"; return f.string(from: dateFromKey(entry.date)).capitalized }
    var body: some View {
        NavigationStack {
            Form {
                Section { Text(readableDate).font(.headline).foregroundStyle(accent) }
                Section("Тип дня") {
                    Picker("Тип", selection: $type) {
                        ForEach(dayTypes.indices, id: \.self) { index in Text(dayTypes[index].1).tag(dayTypes[index].0) }
                        ForEach(customTypes.filter { !$0.deleted }) { Text($0.name).tag("CUSTOM:" + $0.id) }
                    }
                    if type.hasPrefix("CUSTOM:") { TextField("Название", text: $title) }
                }
                Section("Время смены") {
                    HStack { TextField("Начало", text: $start).keyboardType(.numbersAndPunctuation); TextField("Окончание", text: $end).keyboardType(.numbersAndPunctuation) }
                    TextField("Перерыв, минут", text: $pause).keyboardType(.numberPad)
                }
                Section("Заметка") { TextEditor(text: $note).frame(minHeight: 90) }
                Section("Цвет") { paletteRow(selection: selectedColor) { selectedColor = $0 } }
                Section {
                    Button("Вернуть автоматический график", role: .destructive, action: onReset)
                }
            }
            .scrollContentBackground(.hidden).background(Color(red:0.07, green:0.07, blue:0.09))
            .navigationTitle("День и смена")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Сохранить") {
                    let resolvedType = type.hasPrefix("CUSTOM:") ? "OTHER" : type
                    let customName = type.hasPrefix("CUSTOM:") ? (customTypes.first(where: { type == "CUSTOM:" + $0.id })?.name ?? title) : title
                    onSave(ShiftEntry(date: entry.date, type: resolvedType, startTime: start, endTime: end, title: customName, color: selectedColor, note: note, breakMinutes: Int(pause) ?? 0))
                }.foregroundStyle(accent) }
            }
            .onChange(of: type) { newValue in
                if newValue.hasPrefix("CUSTOM:") {
                    if let custom = customTypes.first(where: { newValue == "CUSTOM:" + $0.id }) { selectedColor = custom.color; title = custom.name }
                } else if let standard = dayTypes.first(where: { $0.0 == newValue }) {
                    selectedColor = newValue == "WORK" ? config.accent : standard.2
                    if ["WORK", "EXTRA"].contains(newValue) { if start.isEmpty { start = config.startTime }; if end.isEmpty { end = config.endTime } }
                    else { start = ""; end = "" }
                }
            }
        }
    }
    private func paletteRow(selection: Int64, set: @escaping (Int64) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) { HStack(spacing: 12) { ForEach(palette, id: \.self) { c in Circle().fill(color(c)).frame(width: 28,height: 28).overlay(Circle().stroke(selection == c ? .white : .clear,lineWidth:2).padding(-3)).onTapGesture { set(c) } } }.padding(.vertical, 5) }
    }
}

private extension ContentView {
    func tileColor(_ entry: ShiftEntry) -> Color {
        switch entry.type { case "WORK": return color(entry.color).opacity(0.34); case "REST": return panel.opacity(0.95); case "EXTRA": return Color.orange.opacity(0.28); case "VACATION": return Color.green.opacity(0.25); case "SICK": return Color.pink.opacity(0.25); case "STUDY": return Color.cyan.opacity(0.24); default: return color(entry.color).opacity(0.3) }
    }
    func defaultColor(for type: String) -> Int64 { dayTypes.first(where: { $0.0 == type })?.2 ?? violetARGB }
}

private let violetARGB: Int64 = 0xFFAA91FF
private func typeLabel(_ type: String) -> String { dayTypes.first(where: { $0.0 == type })?.1 ?? type }
private func color(_ argb: Int64) -> Color { let b = UInt32(truncatingIfNeeded: argb); return Color(.sRGB, red: Double((b >> 16) & 255)/255, green: Double((b >> 8) & 255)/255, blue: Double(b & 255)/255, opacity: Double((b >> 24) & 255)/255) }
private func dateFromKey(_ key: String) -> Date { let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone.current; f.dateFormat = "yyyy-MM-dd"; return f.date(from: key) ?? Date() }
private func shiftHours(_ entry: ShiftEntry) -> Double {
    guard let start = minutes(entry.startTime), let end = minutes(entry.endTime) else { return 0 }
    let raw = (end - start + 1440) % 1440
    return max(0, Double(raw - entry.breakMinutes) / 60)
}
private func minutes(_ value: String) -> Int? { let parts = value.split(separator: ":"); guard parts.count == 2, let h = Int(parts[0]), let m = Int(parts[1]), (0...23).contains(h), (0...59).contains(m) else { return nil }; return h * 60 + m }
private func formatHours(_ value: Double) -> String { value.rounded() == value ? String(Int(value)) : String(format: "%.1f", value) }

private struct QRScanner: UIViewControllerRepresentable {
    var onResult: (String?) -> Void
    func makeUIViewController(context: Context) -> ScannerController { let vc = ScannerController(); vc.onResult = onResult; return vc }
    func updateUIViewController(_ uiViewController: ScannerController, context: Context) {}
}
private final class ScannerController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onResult: ((String?) -> Void)?
    private let session = AVCaptureSession()
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .black
        guard let device = AVCaptureDevice.default(for: .video), let input = try? AVCaptureDeviceInput(device: device), session.canAddInput(input) else { onResult?(nil); return }
        session.addInput(input); let output = AVCaptureMetadataOutput(); guard session.canAddOutput(output) else { onResult?(nil); return }; session.addOutput(output); output.setMetadataObjectsDelegate(self, queue: .main); output.metadataObjectTypes = [.qr]
        let preview = AVCaptureVideoPreviewLayer(session: session); preview.videoGravity = .resizeAspectFill; preview.frame = view.bounds; view.layer.addSublayer(preview); DispatchQueue.global(qos: .userInitiated).async { self.session.startRunning() }
    }
    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); view.layer.sublayers?.compactMap { $0 as? AVCaptureVideoPreviewLayer }.first?.frame = view.bounds }
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) { if let value = metadataObjects.first as? AVMetadataMachineReadableCodeObject, let text = value.stringValue { session.stopRunning(); onResult?(text) } }
}
